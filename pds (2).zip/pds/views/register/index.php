<div class="container">
<div class="registerwrapper">
    <h1>Register</h1>
    <div class="alert alert-danger errmsg"> </div>
    <div class="login-content">
        <form action="" class="margin-bottom-0" method="post">
            <div class="form-group ">
                <input type="text" class="form-control form-control-sm" name="fullName" placeholder="Full Name" required />
            </div>
            <div class="form-group ">
                <input type="text" class="form-control form-control-sm" name="username" placeholder="User Name" required />
            </div>
            <div class="form-group ">
                <input type="email" class="form-control form-control-sm" name="email" placeholder="Email Address" required />
            </div>
            <div class="form-group ">
                <input type="password" class="form-control form-control-sm" name="password" placeholder="Password" required />
            </div>
            <div class="form-group ">
                <input type="password" class="form-control form-control-sm" name="cpassword" placeholder="Comfirm Password" required />
            </div>

            <div class="login-buttons">
                <button type="submit" class="btn btn-success btn-block btn-sm sbmit">Register</button>
            </div>
            <div >
                Already Have No Account? Click <a href="<?php echo URL; ?>">here</a> to Login.
            </div>
        </form>
    </div>
</div>
<script type="text/javascript">
   
</script>
</div>