<div class="wrapper">
<h1>Login</h1>
<div class="alert alert-danger errmsg"> </div>
<div class="login-content">
        <form action="" class="margin-bottom-0" method="post">
                    <div class="form-group fo">
                        <input type="email" class="form-control form-control-sm" name="email" placeholder="Email Address" required />
                    </div>
                    <div class="form-group ">
                        <input type="password" class="form-control form-control-sm" name="password" placeholder="Password" required />
                    </div>
                    <div class="checkbox checkbox-css">
                        <input type="checkbox" id="remember_checkbox" /> 
                        <label for="remember_checkbox">
                        	Remember Me
                        </label>
                    </div>
                    <div class="login-buttons">
                        <button type="submit" class="btn btn-success btn-block btn-sm login">Login</button>
                    </div>
                    <div class="m-t-20">
                        Have No Account? Click <a href="<?php echo URL;?>register">here</a> to register.
                    </div>
                </form>
            </div>
</div>