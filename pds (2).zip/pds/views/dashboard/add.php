
<div class="row">


<?php 
require_once("views/dashboard/incs/nav.php");
?>

<div class="column" style="width: 62%;">
    <h1>
        Add Project
    </h1>
    <!-- <center> -->
    <br>
    <div class="panel panel-default">

    <div class="panel-body" style="text-align:center">
  
    <!-- <div class="col col-lg-7"> -->
      <div class="column formTreat" >
    <form action="" method="post">
    <table style="width: 100%;">
    <div class="alert alert-success" style="display: none" id="displayMsg" >
    </div>
    <tbody>
    
    <tr class="form-group">
    <td  style="10rem">
    <label for="title">Matric No:</label>
    </td>
    <td>
    <input type="text" name="matricNo" placeholder="Matric No" class="form-control" id="matricNo">
    </td>
    </tr>
    <tr class="form-group">
    <td>
    <label for="title">Name:</label>
    </td>
    <td>
    <input type="text" name="name" placeholder="Name"  class="form-control" id="name">
    </td>
    </tr >
    <tr class="form-group">
    <td>
    <label for="title">Project Topic:</label>
    </td>
    <td>
    <input type="text" name="projectTopic" placeholder="Project Topic"  class="form-control" id="projectTopic">
    </td>
    </tr>
    <tr class="form-group">
    <td>
    <label for="title">Description:</label>
    </td>
    <td>
    <textarea name="description" id="description" class="form-control"  placeholder="Description" style="width: 100%;" cols="100" rows="3"></textarea>
    <!-- <input type="text" name="title" class="form-control" id="title"> -->
    </td>
    </tr>
    <tr class="form-group">
    <td>
    <label for="title">Supervisor:</label>
    </td>
    <td class="form-group">
    <input type="text" name="supervisor" placeholder="Supervisor" class="form-control" id="supervisor">
    </td>
    </tr>
    <tr>
    <td></td>
    <td>
    <div class="form-group">
        <input type="reset" value="reset" style="display:none" id="reset">
         <button type="button" name="save" id="save" style="font-weight: bolder; font-size: 16pt" class="btn btn-success btn-block">Save</button>
    </div>
    </td>
    </tr>
    </tbody>
    </table >
    </form>
        <!-- </div> -->
    </div>
    </div>   
    </div>
    </div>
    </div>