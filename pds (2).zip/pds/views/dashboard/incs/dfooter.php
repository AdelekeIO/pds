</div>
<!-- C:\xampp\htdocs\pds\views\dashboard\js\default.js -->
<div id="footer" class="footer">
  Copyright&copy;PDS 2018
</div>

</body>
</html>