<!doctype html>
<html>
    <head>
        <title><?= (isset($this->title)) ? S_TITLE . $this->title : 'PSD'; ?></title>
        <link rel="stylesheet" href="<?php echo URL; ?>public/css/bootstrap.min.css" />
        <link rel="stylesheet" href="<?php echo URL; ?>public/css/default.css" />
        <link rel="stylesheet" href="<?php echo URL; ?>public/css/font-awesome.min.css" />
        <script type="text/javascript" src="<?php echo URL; ?>public/js/jquery.js"></script>
        <script type="text/javascript" src="<?php echo URL; ?>public/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="<?php echo URL; ?>public/js/custom.js"></script>
        <!-- C:\xampp\htdocs\pds\views\dashboard\js\default.js -->
        <script type="text/javascript" src="<?php echo URL; ?>public/js/bootbox.min.js"></script>
        
        <!--Assets Themify -->
<!--        <link rel="stylesheet" href="assets/css/normalize.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">-->
    <link rel="stylesheet" href="public/assets/css/font-awesome.min.css">
<!--    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">-->
        <?php
        if (isset($this->js)) {
            foreach ($this->js as $js) {
                echo '<script type="text/javascript" src="' . URL . 'views/' . $js . '"></script>';
            }
        }
        ?>
    </head>
    <body class="bg-light">

        <?php Session::init(); ?>

        <div class="navbar navbar-expand-lg  navbar-dark bg-primary" style="font-size: 14pt">
            <div class="container">
                <a href="<?php echo URL; ?>" class="navbar-brand" id="myLogo">PDS</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav">
                         <?php if (!Session::get('loggedIn')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo URL; ?>register">Register</a>
                        </li>
                        <?php endif; ?>
                    </ul>

                    <ul class="nav navbar-nav ml-auto">
                        <li class="nav-item dropdown navbar-user">
                            <?php if (!Session::get('loggedIn')): ?>
                                <a class="nav-link" href="<?php echo URL; ?>" >About</a>
                            <?php elseif (Session::get('loggedIn') == true) : ?>
                                <a href="javascript:;" class="dropdown-toggle nav-link" data-toggle="dropdown">
                                    <img src="<?php echo URL; ?>public\images\user-13.jpg" alt="T" /> 
                                    <span class="d-none d-md-inline">Welcome <?php echo Session::get('username'); ?></span> <b class="caret"></b>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a href="javascript:;" class="dropdown-item">Edit Profile</a>
                                    <a href="javascript:;" class="dropdown-item"><span class="badge badge-danger pull-right">2</span> Inbox</a>
                                    <a href="javascript:;" class="dropdown-item">Calendar</a>
                                    <a href="javascript:;" class="dropdown-item">Setting</a>
                                    <div class="dropdown-divider"></div>
                                    <a href="javascript:;" class="dropdown-item">Log Out</a>
                                </div>

                            <?php endif; ?>
                        </li>

                    </ul>

                </div>
            </div>
        </div>

        <?php //if (Session::get('loggedIn') == false): ?>
<!--		<a href="<?php echo URL; ?>index">Index</a>
                <a href="<?php echo URL; ?>help">Help</a>-->
        <?php // endif;  ?>	
        <?php // if (Session::get('loggedIn') == true): ?>
<!--		<a href="<?php echo URL; ?>dashboard">Dashboard</a>
                <a href="<?php echo URL; ?>note">Notes</a>-->

        <?php //if (Session::get('role') == 'owner'): ?>
<!--<a href="<?php echo URL; ?>user">Users</a>-->
        <?php // endif; ?>

<!--<a href="<?php echo URL; ?>dashboard/logout">Logout</a>-->	
        <?php // else:  ?>
<!--<a href="<?php echo URL; ?>login">Login</a>-->
        <?php //endif; ?>

        <div id="content">

