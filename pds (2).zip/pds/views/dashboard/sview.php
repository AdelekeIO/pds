<div class="row">


<?php 
require_once("views/dashboard/incs/nav.php");
?>

<div class="column" style="width: 62%;">
   
    <h3>
        VIEW PROJECT DETAILS
    </h3>
    

   <div id="right-panel" class="right-panel">

<!-- Header-->
<!-- /header -->
<!-- Header-->


<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">

        <div class="col-lg-12" style="min-width: 43em;">
            <div class="card">
                <div class="card-header">
                    <strong class="card-title">View Details</strong>
                </div>
                
                <div class="card-body col-lg-12">
                <div class="averages  float-right" style="">
                <h4>Plagiarism Test Analysis</h4>
                <hr>
                <br>
                <div>
                <div >
                <b>Title Average:</b><span id="titleAverage"></span>
                </div>
                <div>
                <b>Description Average:</b><span id="descAverage"></span>
                </div>
                <div>
                <b>Plagiarism Test:</b><span id="plagTest"></span>
                </div>
                </div>
                </div>
                    <div >
                    <div>
                    <table padding="5">
                    <tbody id="vstbody">
                    <tr>
                    <td>Title</td>
                    <td><div id="title"></div></td>
                    </tr>
                    <tr>
                    <td>Matric</td>
                    <td><div id="matric"></div></td>
                    </tr>
                    <tr>
                    <td>Name</td>
                    <td><div id="name"></div></td>
                    </tr>
                    <tr>
                    <td>Supervisor</td>
                    <td><div id="supervisor">
                    </div></td>
                    </tr>
                    <tr>
                    <td>Date Added</td>
                    <td><div id="datetime"></div></td>
                    </tr>
                    <tr>
                    <td>Description</td>
                    <td><div id="description"></div></td>
                    </tr>
                    </tbody>
                    </table>
                </div>
                <div class="container">
                    <button type="submit" id="runtest" class="btn btn-primary">Run Test</button>
                </div>
             
                    </div>
                </div>
            </div>
            
        </div>
        <div class="results col-md-12">
                <div class="card fadein">
                    <div class="card-header">
                    <strong class="card-title">Plagiarism Test Result</strong>
                    </div>
                    <div class="card-body" >
                    <div>
                    </div>
                            <table id="bootstrap-data-table" class="table table-striped table-bordered">
                            <thead>
                            <th>S/N</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Test By Title</th>
                            <th>Test By Description</th>
                            </thead>
                            <tbody id="trslt">
                            
                                
                            </tbody>
                            </table>
                           
                    </div>
                </div>
                </div>

        </div>
    </div><!-- .animated -->
</div><!-- .content -->


</div><!-- /#right-panel -->

<!-- Right Panel -->

    </div>
  </div>


</div>
</div>

    

<!-- kshbsb -->
<!-- <script src="<?php echo URL; ?>public/assets/js/lib/data-table/datatables.min.js"></script>

 <script src="<?php echo URL; ?>assets/js/lib/data-table/datatables.min.js"></script>
    <script src="<?php echo URL; ?>public/assets/js/lib/data-table/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo URL; ?>public/assets/js/lib/data-table/dataTables.buttons.min.js"></script>
    <script src="<?php echo URL; ?>public/assets/js/lib/data-table/buttons.bootstrap.min.js"></script>
    <script src="<?php echo URL; ?>public/assets/js/lib/data-table/jszip.min.js"></script>
    <script src="<?php echo URL; ?>public/assets/js/lib/data-table/pdfmake.min.js"></script>
    <script src="<?php echo URL; ?>public/assets/js/lib/data-table/vfs_fonts.js"></script>
    <script src="<?php echo URL; ?>public/assets/js/lib/data-table/buttons.html5.min.js"></script>
    <script src="<?php echo URL; ?>public/assets/js/lib/data-table/buttons.print.min.js"></script>
    <script src="<?php echo URL; ?>public/assets/js/lib/data-table/buttons.colVis.min.js"></script>
    <script src="<?php echo URL; ?>public/assets/js/lib/data-table/datatables-init.js"></script> -->
    <script src="<?php echo URL; ?>views/dashboard/js/sview.js"></script> 



    