<div class="column">
<div class="row" style="width: 100%;height: 100%;">
 
<?php 
// C:\xampp\htdocs\pds\views\dashboard\incs\nav.php
require_once("views/dashboard/incs/nav.php");
?>

    
    <section style="padding: 30px;background-transparent;">
    &nbsp;
  </section>
  <section class="">
    <div class="container transparent">
      <div class="col-md-2">
        <div >

         <br> <br><br><br>
       
       </div>
      </div>
      <div class="col-md-10">
        <!-- <h3 class="color-orange"> Chat List </h3> -->
      <div style="height: 500px;overflow:auto;background:#FFF">


       <h3>
    Plagiarism Detection System
    <br>

        <div class="col-md-5">
            <div class="form-group">
              <form method="POST" enctype="multipart/form-data">
                <label for="">Profile Picture</label>
                <input type="file" class="form-control" name="fileupload" accept="image/*">
                <p>&nbsp;</p>
                <button class="btn-lg btn btn-info" style="border-radius: 0px !important" name="btnupload"> click to upload </button>
              </form>
            </div>
        </div>
        <div class="col-md-4">

            <?php

                // if(isset($_POST['btnupload'])) {
                //   $fileupload = $_FILES['fileupload']['name'];
                //   $file_name = strtolower($_FILES['fileupload']['name']);
                //   $file_size = ceil($_FILES['fileupload']['size'] / 1024);
                //   $tmp = $_FILES['fileupload']['tmp_name'];
                //   $ext = strrchr($file_name, ".");
                //   $dir = "profile/".time().$ext;
                        
                //   if(move_uploaded_file($tmp, $dir)) {
                //     echo '<img src="'.$dir.'" border="0" style="width: 200px;max-width: 100%;border: 1px solid #ccc;padding: 2px;">';
                    
                //     $save_image = $db->find_by_sql("UPDATE users SET profile='{$dir}' WHERE email='{$uid}'");

                //     echo "<h4>Uploaded Successfully !</h4>";
                //   }     
                // } else {
                //     echo '<img src="images/avatar.png" border="0">';
                // }
                ?>
        
        </div>
        <div class="clearfix"></div>
      </div>
     </div>

     <div class="clearfix"></div>
    </div>
  </section>

   

        </div>
</div>