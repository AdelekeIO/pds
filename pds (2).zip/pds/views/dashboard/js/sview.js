// alert();
$(function(){
    $(".results").css("display","none");

    $(".averages")
        .css("display","none");
        // $("#descAverage")
        // .css("display","none");


var opid=window.location.href.split("=")[1];
var promise=costomPost('xhrSelectById',{id:opid});
promise.done(function(res){
    var json=JSON.parse(res);
    console.log(json);
    if(json.status==true){
        var data=json.data;
        console.log(data);
        $("#vstbody")
        .text("").html(`<tr>
        <td>Title</td>
        <td><div id="title">${data[0].title}</div></td>
        </tr>
        <tr>
        <td>Matric</td>
        <td><div id="matric">${data[0].matric}</div></td>
        </tr>
        <tr>
        <td>Name</td>
        <td><div id="name">${data[0].name}</div></td>
        </tr>
        <tr>
        <td>Supervisor</td>
        <td><div id="supervisor">${data[0].supervisor}
        </div></td>
        </tr>
        <tr>
        <td>Date Added</td>
        <td><div id="datetime">${data[0].datetime}</div></td>
        </tr>
        <tr>
        <td>Description</td>
        <td><div id="description">${data[0].description}</div></td>
        </tr>`);
        }
    console.log(res)
}).fail(function(err){
    console.log(err);
});
    // console.log(window.location.href.split("=")[1]);
})

$("#runtest").click(function(){
    var opid=window.location.href.split("=")[1];
    var promise=costomPost("xhrPlagTest",{id:opid});
    promise.done(function(res){
        console.log(res);
        var json=JSON.parse(res);
        console.log(json);
        // console.log(json.data.length)
        var len=Object.keys(json.data).length;
        // console.log(len);
        var data=json.data;
        var average=json.data[len-1];
        console.log(average);
        var cnt=0;
        if(json.status==true){
            $.each(data,function(key,val){
                // console.log(val);
                if(cnt<(len-1)){
                $("#trslt").append(`
            <tr>
            <td>${++cnt}</td>
            <td>${val.title}</td>
            <td><div style="max-height: 5em !important;  overflow: hidden;">${val.description}</div></td>
            <td>${val.percentByTitle}</td>
            <td>${val.descPercent}</td>
        </tr>
            `);
           
        }
    });
        }

        $(".results").css("display","block");

        $(".averages")
            .css("display","block");


        $("#titleAverage")
        .text(average.titleAverage);
        $("#descAverage")
        .text(average.descAverage);
        $("#plagTest")
        .text(average.plagTest);
    }).fail(function(err){
        console.log(err);
    });
});
function standardGet(port){
	return $.getJSON(port);
 }
 function costomPost(endpoint, fd) {
    return $.ajax({
        url: endpoint,
        data: fd,
        type: 'post'
    });
}

