$(function() {
	// alert("hello world");
	// console.log("Cool");
	$("#save").click(function(){
		// alert("y")
		
		// var form=$("form")[0];
		// console.log($("form"));
		var matric=document.getElementById("matricNo").value;
		// console.log(matric);
		var name=document.getElementById("name").value;
		// console.log(name);
		var projectTopic=document.getElementById("projectTopic").value;
		// console.log(projectTopic);
		var description=document.getElementById("description").value;
		// console.log(description);
		var supervisor=document.getElementById("supervisor").value;
		// console.log(supervisor);
		
		// var name=form[1].text;
		// var pt= form[2].text;
		// var desc=form[3].text;
		// var supervisor=form[4].text;

		if(!costomValidator(matric)){
			// alert("Kindly enter your Matric No");
			showErrMessage("Kindly enter your Matric No");
			$("#matricNo").focus();
			return false;
		}
		if(!costomValidator(name)){
			// alert("Kindly enter your Name");
			showErrMessage("Kindly enter your Name");
			$("#name").focus();
			return false;
		}
		if(!costomValidator(projectTopic)){
			// alert("Kindly enter Projectc topic");
			showErrMessage("Kindly enter Project topic");
			$("#projectTopic").focus();
			return false;
		}
		if(!costomValidator(description)){
			// alert("Kindly enter your Description");
			showErrMessage("Kindly enter your Description");
			$("#description").focus();
			return false;
		}
		if(!costomValidator(supervisor)){
			// alert("Kindly enter your Supervisor");
			showErrMessage("Kindly enter your Supervisor");
			$("#supervisor").focus();
			return false;
		}
		var data={
			matric:matric,
			name:name,
			projectTopic:projectTopic,
			description:description,
			supervisor:supervisor
		}
		// console.log(data);
		var promise=costomPost("xhrInsert",data);
		promise.done(function (res){
			console.log(res);
			var json=JSON.parse(res);
			console.log(json);
			if(json.status==true){
				showSuccessMessage(json.message);
				$("#reset").click();
			}else if(json.status==false){
				showErrMessage(json.message);
			}
		}).fail(function (err){
			console.log(err);
		});
		// console.log(matric+name+pt+desc+supervisor)

	});

	

// 	$.get('dashboard/xhrGetListings', function(o) {
		
// 		for (var i = 0; i < o.length; i++)
// 		{
// 			$('#listInserts').append('<div>' + o[i].text + '<a class="del" rel="'+o[i].id+'" href="#">X</a></div>');
// 		}
		
// //		$('.del').live('click', function() {
// //			delItem = $(this);
// //			var id = $(this).attr('rel');
// //			
// //			$.post('dashboard/xhrDeleteListing', {'id': id}, function(o) {
// //				delItem.parent().remove();
// //			}, 'json');
// //			
// //			return false;
// //		});
		
// 	}, 'json');
	
	
	
	// $('#randomInsert').submit(function() {
	// 	var url = $(this).attr('action');
	// 	var data = $(this).serialize();
		
	// 	$.post(url, data, function(o) {
	// 		$('#listInserts').append('<div>' + o.text + '<a class="del" rel="'+ o.id +'" href="#">X</a></div>');		
	// 	}, 'json');
		
		
	// 	return false;
	// });

});
function standardGet(port){
	return $.getJSON(port);
 }
 function costomValidator(val) {
    if (val.length === 0 || val === "" || val.trim()==='Gender' || val === undefined || val === null || val === NaN || val.trim()==="How did you hear about MAP meet up?") {
        return false;
    } else {
        return true;
    }
}
function costomPost(endpoint, fd) {
    return $.ajax({
        url: endpoint,
        data: fd,
        type: 'post'
    });
}
function showErrMessage(msg){
	$("#displayMsg")
	.removeClass("alert-success")
	.addClass("alert-danger")
	.text(msg)
	.css("display","block");
}
function showSuccessMessage(msg){
	$("#displayMsg")
	.removeClass("alert-danger")
	.addClass("alert-success")
	.text(msg)
	.css("display","block");
}

$(document).ready(function(){
	
	var promise=standardGet("xhrGetListings");
	
	var sn=0;
	promise.done(function(res){
		// alert("hello");
		$.each(res, function (key, val) {
			// console.log(val);
			// console.log($("vtbody"));
			$("#vtbody")
			.append('<tr><td><input type="radio" value="'+val.id+'" name="opts" id="opts'+val.id+'">'+(++sn)+'</td><td>'+val.title+'</td><td><div style="max-height: 5em !important;  overflow: hidden;">'+val.description+'</div></td><td>'+val.supervisor+'</td><td>'+val.datetime+'</td></tr>');
		});
	}).fail(function(err){
		// console.log(err);
	});
});

$(document).on('click','#searchbtn',function(e){
	e.preventDefault();
	var searchVal=$("#search").val().trim();
	if(searchVal==="" || searchVal.length===0){
		alert("Kindly Fill the Sesrch Box");
		$("#search").focus();
		return;
	}
	// console.log('search');
	var promise=costomPost('xhrSearch',{value:searchVal});
	var sn=0;
	promise.done(function(res){
		// console.log(res);
		var json=JSON.parse(res);
		if(json.status==true){
			var sr=(json.data);
		$.each(sr,function(key,val){
			// console.log(val.id);
			$("#vtbody").text("")
		.append('<tr><td><input type="radio" name="opts" value="'+val.id+'" id="opts'+val.id+'">'+(++sn)+'</td><td>'+val.title+'</td><td><div style="max-height: 5em !important;  overflow: hidden;">'+val.description+'</div></td><td>'+val.supervisor+'</td><td>'+val.datetime+'</td></tr>');
		});
		}else{

		}
		
	}).fail(function(err){
		console.log(err);
	});
});
// alert();
$(document).on('click','#del',function(e){
	e.preventDefault();
	// console.log(e);
	
	var check=$("[name='opts']:checked")[0];
	var vals=[];
	
	$.each($("[name='opts']:checked"),function(key,val){
		vals.push($(this).val().trim());
		
	});
	console.log(vals[0]);
	if(vals[0]===undefined){
		alert("Kindly Select The Record To Delete.");
	}else if(confirm("Do You Really Want To Delete?")){
	var promise=costomPost("xhrDeleteListing",{id:vals[0]});
	promise.done(function(res){
		console.log(res);
			var json=JSON.parse(res);
			if(json.status==true){
				alert("Deleted Successfully");
				window.location.reload();
				// var sr=(json.data);
			}
		
	}).fail(function(err){
		console.log(err);
	});
	// console.log("hee");
}
});

$(document).on('click','#view',function(e){
	e.preventDefault();
	console.log(e);
	// console.log("hee");
	// $("[name='opts']:checked")[0];
	var check=[];
	$.each($("[name='opts']:checked"),function(key,val){
		check.push($(this).val());
		// console.log($(this).val());
	});
	
	console.log(check[0]);	
	window.location.href="http://localhost:808/pds/dashboard/sview?xheck="+check[0];
	// console.log($("#mediumModal"));
});
$(document).on('click','#logout',function(e){
	// console.log(e);
	e.preventDefault();
	var loc=window.location.href;
	var url;
	console.log(loc);
	if(loc==="http://localhost:808/pds/dashboard"){
		url="dashboard/xhrLogOut";
	}else{
		url="xhrLogOut";
	}
	var promise=costomPost(url);
	promise.done(function(res){
		console.log(res);
		window.location.reload();
		// window.location.replace("http://localhost:808/pds/");
	}).fail(function(err){
		console.log(err);
	});
// alert();
});