<div class="row">


<?php 
require_once("views/dashboard/incs/nav.php");
?>

<div class="column" style="width: 62%;">
   
    <h3>
        VIEW PROJECTS
    </h3>
    <div class="searchContainer" style="margin-left: 15pt;">
    <form action="" method="get" class="row">
      <input type="text" name="search" id="search" style="width: 90%;" class="form-control" placeholder="Search By Title ... " id="search">
      <button id="searchbtn" style="padding: 0.2em;border-radius: 0.25em">Search</button>
      <!-- <input type="submit" value="Search"> -->
    </form>
  </div>

   <div id="right-panel" class="right-panel">

<!-- Header-->
<!-- /header -->
<!-- Header-->


<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">

        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <strong class="card-title">Data Table</strong>
                </div>
                <!-- hdhd -->
                <div class="breadcrumbs">
            <div class="col-sm-4">
                <!-- <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Dashboard</h1>
                    </div>
                </div> -->
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a id="view" href="#"><button class="btn btn-success btn-sm" type="submit">View</button></a></li>
                            <li ><a id="del" href="#"><button  class="btn btn-danger btn-sm" type="submit">Delete</button></a></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
                <!-- bnskbs -->
                <div class="card-body">
          <table id="bootstrap-data-table" class="table table-striped table-bordered">
            <thead>
              <tr>
                <th>S/N</th>
                <th>Title</th>
                <th>Abstract</th>
                <th>Supervisor</th>
                <!-- <th>Plagiarism Test Result</th> -->
                <th>Date Added</th>
              </tr>
            </thead>
            <tbody id="vtbody">
            </tbody>
          </table>
                </div>
            </div>
        </div>


        </div>
    </div><!-- .animated -->
</div><!-- .content -->


</div><!-- /#right-panel -->

<!-- Right Panel -->

    </div>
  </div>


</div>
</div>

    

<!-- kshbsb -->
<!-- <script src="<?php echo URL; ?>public/assets/js/lib/data-table/datatables.min.js"></script>

 <script src="<?php echo URL; ?>assets/js/lib/data-table/datatables.min.js"></script>
    <script src="<?php echo URL; ?>public/assets/js/lib/data-table/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo URL; ?>public/assets/js/lib/data-table/dataTables.buttons.min.js"></script>
    <script src="<?php echo URL; ?>public/assets/js/lib/data-table/buttons.bootstrap.min.js"></script>
    <script src="<?php echo URL; ?>public/assets/js/lib/data-table/jszip.min.js"></script>
    <script src="<?php echo URL; ?>public/assets/js/lib/data-table/pdfmake.min.js"></script>
    <script src="<?php echo URL; ?>public/assets/js/lib/data-table/vfs_fonts.js"></script>
    <script src="<?php echo URL; ?>public/assets/js/lib/data-table/buttons.html5.min.js"></script>
    <script src="<?php echo URL; ?>public/assets/js/lib/data-table/buttons.print.min.js"></script>
    <script src="<?php echo URL; ?>public/assets/js/lib/data-table/buttons.colVis.min.js"></script>
    <script src="<?php echo URL; ?>public/assets/js/lib/data-table/datatables-init.js"></script> -->



    