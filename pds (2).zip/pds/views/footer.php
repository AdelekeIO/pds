</div>
<script type="text/javascript" src="<?php echo URL; ?>public/js/jquery.js"></script>
        <script type="text/javascript" src="<?php echo URL; ?>public/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="<?php echo URL; ?>public/js/custom.js"></script>
        <script type="text/javascript" src="<?php echo URL; ?>public/js/bootbox.min.js"></script>
<div id="footer" class="footer">
  Copyright&copy;PDS 2018
</div>

</body>
</html>