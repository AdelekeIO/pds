$(document).ready(function () {
//Hadles Registration\ 
    $('.sbmit').click(function (e) {
        e.preventDefault();
        var point = "register/run";
        var fname = (allProcesses('fullName'));
        if (fname === "" || fname === undefined) {
            showErrorMessage('fullName');
            return;
        }
        var uname = (allProcesses('username'));
        if (uname === "" || uname === undefined) {
            showErrorMessage('username');
            return;
        }
        var em = (allProcesses('email'));
        if (em === "" || em === undefined) {
            showErrorMessage('email');
            return;
        }
        if (!validateEmail('email')) {
            showErrorMessage('email', 'Kindly Supply a valid email');
            return;
        }
        var pw = (allProcesses('password'));
        if (pw === "" || pw === undefined) {
            showErrorMessage('email');
            return;
        }
        var cpw = (allProcesses('cpassword'));
        if (cpw === "" || cpw === undefined) {
            showErrorMessage('cpassword');
            return;
        } else if (cpw !== pw) {
            showErrMessage('Password and confirm password does not match');
            return;
        }

        var regDat = {
            fullName: fname,
            username: uname,
            email: em,
            password: pw,
            cpassword: cpw
        };

        // console.log(regDat);

        // return;
        $('.errmsg').html('This field ' + name + ',is required.').css('display', 'none');
        if ((regDat.email !== "" && regDat.email !== undefined) && (regDat.username !== "" && regDat.username !== undefined) && (regDat.fullName !== "" && regDat.fullName !== undefined) && (regDat.password !== "" && regDat.password !== undefined)) {
            var promise = costomPost(point, regDat);
            promise.done(function (res) {

                               console.log(res);
                               
                var json = JSON.parse(res);
                               console.log(json);

                            // return;
                if (json.status === true) {
                    showSuccessMessage(json.message);
                    window.location.href = 'index';
                }
            }).fail(function (err) {
            //    console.log(err);
            });
        }

    });

    /*************************************************************************************************
     * 
     *  Logins
     * ***********************************************************************************************
     */
//Logins
    $('.login').click(function (e) {
        e.preventDefault();
        var point = "index/run";
        var em = (allProcesses('email'));
        if (em === "" || em === undefined) {
            showErrorMessage('email');
            return;
        }
        var pw = (allProcesses('password'));
        if (pw === "" || pw === undefined) {
            showErrorMessage('password');
            return;
        }
        var loginDat = {
            email: em,
            password: pw
        };
        $('.errmsg').html('').css('display', 'none');
        // console.log(loginDat);
        if ((loginDat.email !== "" && loginDat.email !== undefined) && (loginDat.password !== "" && loginDat.password !== undefined)) {
            var promise = costomPost(point, loginDat);
            promise.done(function (res) {
                // console.log(res);
                // return;
                var json = JSON.parse(res);
//                                console.log(json);
                if (json.status === true) {
                    showSuccessMessage(json.message);
                    window.location.replace("dashboard/add");
                } else if (json.status === false) {
                    showErrMessage(json.message);
                }
            }).fail(function (err) {
//                console.log(err);
            });
        }
    });
});

/**
 * 
 * 
 *  *****************************************Functions Below ***********************************
 * 
 */

allProcesses = function (name) {
    getValueByName = function (name) {
        var res = costomValidator($(document).find('input[name=' + name + ']').val().trim());
        if (res === false) {
            return false;
        } else
            return res;
    };

    costomValidator = function (val) {
        // console.log(val);
        if (val.length === 0 && val === "" && val.trim() === 'Select Connection Type' && val === undefined && val === null && val === NaN) {
            return false;
        } else {
            return val;
        }
    };
    return getValueByName(name);
};

function costomPost(endpoint, fd) {
    return $.ajax({
        url: endpoint,
        data: fd,
        type: 'post'
    });
}


showErrorMessage = function (name, msg = null) {
    if (msg !== null) {
        $('.errmsg').html(msg).css('display', 'block');
    } else {
        $('.errmsg').html('This field ' + name + ',is required.').css('display', 'block');
        $(document).find('input[name=' + name + ']').focus();
}
};

showSuccessMessage = function (msg = null) {
    $('.errmsg').removeClass('alert-danger')
            .addClass('alert-success')
            .html(msg).css('display', 'block');

};

function validateEmail(email) {
    var addr = $(document).find('input[name=' + email + ']').val();
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(addr);
}
showErrMessage = function (msg = null) {
    $('.errmsg').removeClass('alert-success')
            .addClass('alert-danger')
            .html(msg).css('display', 'block');
}

/**
 * 
 * Toggle sidebar
 */
$(document).ready(function () {

    // $('#sidebarCollapse').on('hover', function () {
    //     $('#sidebar').toggleClass('active');
    // });

});