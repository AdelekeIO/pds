-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 22, 2018 at 03:03 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pds`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(5) NOT NULL,
  `uuid` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `username` text NOT NULL,
  `datetime` text NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `uuid`, `email`, `password`, `username`, `datetime`, `status`) VALUES
(1, 'b171d1b2160e1a1c370405f22d821d8bc673403b13eb4a3b67f58af3bf7ba9fb', 'test@pds.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'test', '2018-10-19 17:44:46', 0),
(2, '486b5642b7f3a65f085b9385b1c01afd041205cbe2efdda7d60c0e4e9a658601', 'test@pds.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'test', '2018-10-19 17:46:22', 0),
(3, '015a89683182790e094d95ce675f88b6e7158950420304b6b2d4421a6def1899', 'test@pds.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'test', '2018-10-19 17:47:07', 0),
(4, 'd892d075cac282bccbb10c12d35ec821c8d0485786c3d337e2fad3884e3eff11', 'test@pds.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'test', '2018-10-19 17:47:22', 0),
(5, 'ad12cdaa0ef65ed1527c3efd3c4fc00327e0214f8e3934c7504deae879ac068b', 'test@pds2.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'test', '2018-10-19 17:47:53', 0),
(6, 'd158e81ea744df86340cf1e1176f3558013d4896c7e51e81bf9f6bbf6798de19', 'test@pds1.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'test', '2018-10-19 17:48:38', 0);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `fullName` text NOT NULL,
  `username` text NOT NULL,
  projects`email` text NOT NULL,
  `password` text NOT NULL,
  `comfirmPassword` text NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `fullName`, `username`, `email`, `password`, `comfirmPassword`, `status`) VALUES
(4, 'Admin', 'Admin', 'Admin@pds.com', '87474a8eaecb06cf97ff8fe4c0c58389f032de00bbc3af4b81115446984ab310', '87474a8eaecb06cf97ff8fe4c0c58389f032de00bbc3af4b81115446984ab310', 0),
(5, 'Admin@pds.com', 'Admin@pds.com', 'Admin@pds.com', 'db2a43c60d6a89d12cda1af8d5e6a34dee74315c4acbb5861bc7487332adf562', 'db2a43c60d6a89d12cda1af8d5e6a34dee74315c4acbb5861bc7487332adf562', 0),
(6, 'Admin@pds.com', 'Admin@pds.com', 'Admin@pds.com', 'db2a43c60d6a89d12cda1af8d5e6a34dee74315c4acbb5861bc7487332adf562', 'db2a43c60d6a89d12cda1af8d5e6a34dee74315c4acbb5861bc7487332adf562', 0),
(7, 'Admin@pds.com', 'Admin@pds.com', 'Admin@pds.com', 'db2a43c60d6a89d12cda1af8d5e6a34dee74315c4acbb5861bc7487332adf562', 'db2a43c60d6a89d12cda1af8d5e6a34dee74315c4acbb5861bc7487332adf562', 0),
(8, 'Admin@pds.com', 'Admin@pds.com', 'Admin@pds.com', 'db2a43c60d6a89d12cda1af8d5e6a34dee74315c4acbb5861bc7487332adf562', 'db2a43c60d6a89d12cda1af8d5e6a34dee74315c4acbb5861bc7487332adf562', 0),
(9, 'Admin@pds.com', 'Admin@pds.com', 'Admin@pds.com', 'db2a43c60d6a89d12cda1af8d5e6a34dee74315c4acbb5861bc7487332adf562', 'db2a43c60d6a89d12cda1af8d5e6a34dee74315c4acbb5861bc7487332adf562', 0),
(10, 'Admin@pds.com', 'Admin@pds.com', 'Admin@pds.com', 'db2a43c60d6a89d12cda1af8d5e6a34dee74315c4acbb5861bc7487332adf562', 'db2a43c60d6a89d12cda1af8d5e6a34dee74315c4acbb5861bc7487332adf562', 0),
(11, 'Admin@pds.com', 'Admin@pds.com', 'Admin@pds.com', 'db2a43c60d6a89d12cda1af8d5e6a34dee74315c4acbb5861bc7487332adf562', 'db2a43c60d6a89d12cda1af8d5e6a34dee74315c4acbb5861bc7487332adf562', 0),
(12, 'Admin@pds.com', 'Admin@pds.com', 'Admin@pds.com', 'db2a43c60d6a89d12cda1af8d5e6a34dee74315c4acbb5861bc7487332adf562', 'db2a43c60d6a89d12cda1af8d5e6a34dee74315c4acbb5861bc7487332adf562', 0),
(13, 'Admin@pds.com', 'Admin@pds.com', 'Admin@pds.com', 'db2a43c60d6a89d12cda1af8d5e6a34dee74315c4acbb5861bc7487332adf562', 'db2a43c60d6a89d12cda1af8d5e6a34dee74315c4acbb5861bc7487332adf562', 0),
(14, 'kk', 'kk', 'kk@kk.com', '279ed7688ba3b3a2573d43112bfdd8bff2ec07cff55bdf1e6401e6403f250652', '279ed7688ba3b3a2573d43112bfdd8bff2ec07cff55bdf1e6401e6403f250652', 0),
(15, 'kk', 'kk', 'kk@kk.kk', '279ed7688ba3b3a2573d43112bfdd8bff2ec07cff55bdf1e6401e6403f250652', '279ed7688ba3b3a2573d43112bfdd8bff2ec07cff55bdf1e6401e6403f250652', 0),
(16, 'test', 'test', 'test@pds.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 0),
(17, 'test', 'test', 'test@pds.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 0),
(18, 'test', 'test', 'test@pds.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 0),
(19, 'test', 'test', 'test@pds.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 0),
(20, 'test', 'test', 'test@pds.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 0),
(21, 'test', 'test', 'test@pds.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 0),
(22, 'test', 'test', 'test@pds.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 0),
(23, 'test', 'test', 'test@pds.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 0),
(24, 'test', 'test', 'test@pds.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 0),
(25, 'test', 'test', 'test@pds.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 0),
(26, 'test', 'test', 'test@pds.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 0),
(27, 'test', 'test', 'test@pds.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 0),
(28, 'test', 'test', 'test@pds.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 0),
(29, 'test', 'test', 'test@pds.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 0),
(30, 'test', 'test', 'test@pds.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 0),
(31, 'test', 'test', 'test@pds.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 0),
(32, 'test', 'test', 'test@pds.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 0),
(33, 'test', 'test', 'test@pds.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 0),
(34, 'test', 'test', 'test@pds.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 0),
(35, 'test', 'test', 'test@pds2.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 0),
(36, 'test', 'test', 'test@pds1.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
