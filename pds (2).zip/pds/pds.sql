-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 29, 2018 at 07:25 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pds`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `ID` int(11) NOT NULL,
  `uuid` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `datetime` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`ID`, `uuid`, `email`, `password`, `username`, `datetime`, `status`) VALUES
(15, '1479d5824a3b3bdadd03e05904024a021faf338a9ebe1c863ba5cc59ad2f5626', 'admin@map.com', 'a9c7040a171ea47c677bd4da2d9009bf5a67691108ced369d8ef9ff4a30a80d6', '', '2018-08-22 22:59:27', 0),
(16, '8d1c01372db9e9c0499c4df1fa291c7d56ecf5af36d6159b5187990df655bc71', 'mary@pds.com', '471cab795d3c164944cfcadbd626e8d6648bf52a7685aa0f397313e6df819dad', 'MaryMG', '2018-08-24 00:36:28', 0),
(17, 'a52b25653a7683ca42e9d5621a562e72432d691c609971e521edbabede16c4c5', 'tom.shegzy@gmail.com', 'cab608313f85a043355c9a57863bb360ceb856382957f5873fceff9c20776cc2', 'shegzy', '2018-10-18 13:33:39', 0),
(18, 'd158e81ea744df86340cf1e1176f3558013d4896c7e51e81bf9f6bbf6798de19', 'test@pds1.com', 'dbc63eeded5452f7ed8d11d645de459d7027d8b19742521f4460119ba7b53e24', 'test', '2018-10-19 17:48:38', 0);

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int(11) NOT NULL,
  `matric` varchar(50) NOT NULL DEFAULT '0',
  `name` varchar(222) NOT NULL DEFAULT '0',
  `title` text NOT NULL,
  `description` text NOT NULL,
  `supervisor` text NOT NULL,
  `datetime` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `matric`, `name`, `title`, `description`, `supervisor`, `datetime`, `status`) VALUES
(5, 'fkkfk', 'kdkdk', 'kdfksd', 'kdckdk', 'fkfkf', '2018-10-25 09:35:54', 0),
(7, 'dodpe', 'smsms', 'dmmdmdmdm', 'mdmdmdmdmdmdmdmm', 'dmdmdmdmdmdmd', '2018-10-25 09:59:58', 0),
(8, 'Hello', 'My Name', 'Do It', 'Doing It', 'Me', '2018-10-25 10:55:23', 0),
(9, 'ksbsbsb', 'ndndndnbsdn', 'lknvcnnsfn', 'ndfnfdgnffnqnfn', 'lndfvnfvnfnf', '2018-10-25 10:59:23', 0),
(10, '33/33/33', 'Adeleke Isaiah Olusegun', 'Lorem Details', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ipsum, ex? Odit, quas? Repellat impedit aliquid soluta est ut magnam dignissimos cumque culpa quas! Similique nulla facere consectetur, architecto amet ratione soluta repellat minus unde ipsam voluptas consequatur aspernatur provident perspiciatis aliquam qui perferendis dicta hic repellendus. Alias nulla, totam incidunt corrupti fugit similique expedita blanditiis! Dignissimos veritatis natus reprehenderit aliquam, ipsam corrupti mollitia error minus sequi esse ea sapiente, quod ab saepe necessitatibus blanditiis magnam alias ratione dolorem modi totam exercitationem eius! Accusantium rem et ab debitis sed, rerum voluptatum nisi, laudantium minima ullam facere eius perferendis inventore. Ab impedit ullam reprehenderit obcaecati architecto ex reiciendis, earum doloribus deleniti cupiditate velit consequuntur ad maxime fugiat quis sit nihil magni debitis aspernatur itaque sunt autem dolores totam. Quibusdam quaerat culpa alias sapiente ratione odio quae, quam consectetur qui non, voluptates veniam repellat natus cum laudantium suscipit? Dolorum iusto soluta voluptates vitae optio in assumenda quam voluptatum aliquam esse, illum maiores deserunt doloribus, totam placeat excepturi itaque amet? Nemo consequuntur mollitia dolores illo. Facilis explicabo tenetur labore maxime natus quod nam quas sint temporibus minima. Expedita ex repellendus sed corrupti vero possimus ea animi aliquam velit, sint ipsa numquam. Voluptatum vitae similique quos sit culpa consequuntur ullam eaque non debitis error, autem voluptas, aspernatur beatae nulla, architecto nostrum adipisci libero. Vel nesciunt excepturi quasi sunt praesentium! Nesciunt dicta aperiam dolores repellendus maiores, id, ducimus voluptates aut iure maxime quisquam beatae numquam sapiente perferendis! Ipsam ratione necessitatibus repellendus aspernatur quibusdam, blanditiis doloribus possimus eligendi, modi, vel mollitia beatae cum! Obcaecati, autem quis iste amet reprehenderit sit illo quam, alias nisi rerum, ipsam pariatur. Debitis laudantium ipsa aliquid, perferendis aperiam, repellat voluptatem vel ea asperiores consequuntur numquam rerum ut illum, autem et praesentium veniam! Sunt quisquam unde deserunt id repudiandae debitis eveniet quod rem, autem amet excepturi necessitatibus expedita non voluptatibus dolorum neque, ratione labore suscipit sit doloremque aspernatur. Nostrum eum vel voluptatem quia quisquam minima dignissimos consequatur facilis est, deleniti, modi odio ex aut exercitationem libero maiores, inventore nulla. Voluptates quam molestias eos fugiat quasi inventore ad mollitia nemo repellat ipsa ullam harum perferendis iusto velit quas corporis doloremque, dolorem esse excepturi neque nam aut. Sequi, voluptate? Corporis esse neque, commodi accusantium incidunt eos voluptate id architecto blanditiis obcaecati quae alias rem nihil dicta vel, modi quo fugiat repellendus eum libero laboriosam est ab dolorum! Inventore tenetur beatae illo necessitatibus cumque omnis dolorem provident. Dicta dignissimos quasi iusto omnis temporibus perferendis qui totam harum voluptatum unde officiis inventore, ratione laboriosam vitae expedita placeat possimus minima accusamus laborum deleniti non cum corrupti nam dolorem! Ullam eos ex dolorum eaque odit! Fugit exercitationem animi, facere beatae nesciunt aliquam odio facilis dolores quo necessitatibus rerum consequuntur? Quae, ut. Nam vitae fugiat consequatur iste voluptas sed doloribus, perspiciatis aliquid atque repellat natus, recusandae commodi optio ut, laboriosam facere cum delectus quo omnis? Corporis officia ipsam quod aliquid deserunt ut? Id nemo esse, nulla quo commodi rerum obcaecati incidunt nobis omnis, accusamus sapiente? Officiis sint in debitis et?\n', 'Mr Akanbi', '2018-10-28 03:42:30', 0),
(11, 'necessitatibus', 'necessitatibus', 'necessitatibus', '               Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem nisi consequuntur ea odio possimus quaerat itaque iure officia? Consequatur perspiciatis dolore molestiae possimus est necessitatibus exercitationem amet corrupti, optio, rerum suscipit. Eaque nulla tempora porro dolorem! Quae tempore deserunt sint?\n', 'Mr necessitatibus', '2018-10-28 04:20:32', 0);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(4) NOT NULL,
  `fullName` varchar(251) DEFAULT NULL,
  `email` varchar(251) DEFAULT NULL,
  `username` varchar(251) DEFAULT NULL,
  `password` varchar(251) DEFAULT NULL,
  `comfirmPassword` varchar(251) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To register All Users';

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `fullName`, `email`, `username`, `password`, `comfirmPassword`) VALUES
(17, 'admin@map.com', 'admin@map.com', 'admin@map.com', 'a9c7040a171ea47c677bd4da2d9009bf5a67691108ced369d8ef9ff4a30a80d6', 'a9c7040a171ea47c677bd4da2d9009bf5a67691108ced369d8ef9ff4a30a80d6'),
(18, 'Mary', 'mary@pds.com', 'MaryMG', '471cab795d3c164944cfcadbd626e8d6648bf52a7685aa0f397313e6df819dad', '471cab795d3c164944cfcadbd626e8d6648bf52a7685aa0f397313e6df819dad'),
(19, 'Mary', 'mary@pds.com', 'MaryMG', '471cab795d3c164944cfcadbd626e8d6648bf52a7685aa0f397313e6df819dad', '471cab795d3c164944cfcadbd626e8d6648bf52a7685aa0f397313e6df819dad'),
(20, 'Mary', 'mary@pds.com', 'MaryMG', '471cab795d3c164944cfcadbd626e8d6648bf52a7685aa0f397313e6df819dad', '471cab795d3c164944cfcadbd626e8d6648bf52a7685aa0f397313e6df819dad'),
(21, 'mary@pds.com', 'mary@pds.com', 'mary@pds.com', '471cab795d3c164944cfcadbd626e8d6648bf52a7685aa0f397313e6df819dad', '471cab795d3c164944cfcadbd626e8d6648bf52a7685aa0f397313e6df819dad'),
(22, 'mary@pds.com', 'mary@pds.com', 'mary@pds.com', '471cab795d3c164944cfcadbd626e8d6648bf52a7685aa0f397313e6df819dad', '471cab795d3c164944cfcadbd626e8d6648bf52a7685aa0f397313e6df819dad'),
(23, 'Adeleke Isaiah Olusegun', 'tom.shegzy@gmail.com', 'shegzy', 'cab608313f85a043355c9a57863bb360ceb856382957f5873fceff9c20776cc2', 'cab608313f85a043355c9a57863bb360ceb856382957f5873fceff9c20776cc2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
