<?php

class FineMessages
{
    /*
     * @param
     */
  
        /**
	 *
	 * @param string $data The array with status, data,and message
	 * @return json 
	 */
	public static function word( $data)
	{	

		switch(count($data)){
		case '3':
		$data=array('status'=>$data[0],'data'=>$data[1],'message'=>$data[2]);
		break;
		case '2':
		$data=array('status'=>$data[0],'message'=>$data[1]);
		break;
		default:
		$data=array($data);
		break;
		}	
        $json= json_encode($data);
	echo $json;
		
	}
	
}