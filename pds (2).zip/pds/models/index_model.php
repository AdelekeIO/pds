<?php

class Index_Model extends Model {

    public function __construct() {
        parent::__construct();
    }

    public function run() {
//              email: em,
//            password: pw
        $sth = $this->db->prepare("SELECT * FROM login  WHERE email=:username  && password = :password");
        $sth->execute(array(
            ':username' => $_POST['email'],
            ':password' => Hash::create('sha256', $_POST['password'], HASH_PASSWORD_KEY)
        ));
        $data = $sth->fetch();
        $count = $sth->rowCount();
        // echo ($data);
        // print_r($data);
        
        // print_r($count);
        // die();
        if ($count > 0) {
            // login
            Session::init();
            Session::set('email', $data['email']);
            Session::set('loggedIn', true);
            Session::set('uuid', $data['uuid']);
            Session::set('username', $data['username']);
             FineMessages::word($this->_data = array(true,'','Signed In Successfully'));
        } else {
             FineMessages::word($this->_data = array(false,'','Invalid User Email or Password'));
        }
    }

}
