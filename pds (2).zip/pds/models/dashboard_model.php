<?php

class Dashboard_Model extends Model {
	// echo "de";
	public $_res1=null;
	public $_titlePercentSum;
	public $_descPercentSum;
	public function __construct() {
		parent::__construct();
	}
	
	public function xhrInsert() 
	{
		// echo ("Dbs is here");
				// print_r($_POST);

		
		$matric = $_POST['matric'];
		$name = $_POST['name'];
		$projectTopic = $_POST['projectTopic'];
		$description = $_POST['description'];
		$supervisor = $_POST['supervisor'];

		

		// die();
		$this->_res1=$this->db->insert('projects', array(
			'matric' => $matric,
			'name' => $name,
			'title' => $projectTopic,
			'description' => $description,
			'supervisor'=>$supervisor,
			'datetime'=> date('Y-m-d H:i:s', time()) ,
			'status'=>'0'
		));
		
		FineMessages::word($this->_successMsg=array(TRUE,$this->_res1,'Project Added Successfully'));
		// die();


		// $data = array('id' => $this->db->lastInsertId());
		// echo json_encode($_res1);
		// echo($this->_res1);
	}
	
	public function xhrGetListings()
	{
		$result = $this->db->select("SELECT * FROM projects ORDER BY id Desc");
		// similar_text();
		echo json_encode($result);
	}
	public function xhrSearch()
	{
		// $serchBy=$_REQUEST['key'];
		$serchValue=strtolower($_REQUEST['value']);
	
	
		$res=$this->db->searchSelect('projects',$serchValue);
		if(!empty($res)){
			FineMessages::word($this->_successMsg=array(TRUE,$res,'Search Result'));
		}else{
			FineMessages::word($this->_successMsg=array(false,'No Search Result'));
        }
		
	}
	public function xhrPlagTest()
	{
		$serchValue=array("id"=>strtolower($_REQUEST['id']));
		$sql="SELECT title, description FROM projects WHERE id=:id";
		$fRes=$this->db->select($sql,$serchValue);
		$sql="SELECT id, title, description FROM projects WHERE id!=:id";
		$multiRes=$this->db->select($sql,$serchValue);
		$titleSim=array();
		$descSim=array();
		$titleSimVal=array();
		
		// print_r("count :".count($multiRes)."\n");
		foreach ($multiRes as $key => $value) {
			
			similar_text(strtolower($fRes[0]['title']),strtolower($value['title']),$titlePercent);
			similar_text(strtolower($fRes[0]['description']),strtolower($value['description']),$descPercent);
			if((int)$titlePercent>=20 || (int)$descPercent>=20){
				$this->_titlePercentSum+=$titlePercent;
				$this->_descPercentSum+=$descPercent;
				$tv=$value['id'];
				array_push($titleSim,(array('id'=>$tv,'title'=>$value['title'],'description'=>$value['description'],
				'percentByTitle'=>$titlePercent."%",'descPercent'=>$descPercent."%"
			)));
				array_push($titleSimVal,implode(',',array_values(array('id'=>$tv,'title'=>$value['title'],'description'=>$value['description'],
				'percentByTitle'=>$titlePercent."%",'descPercent'=>$descPercent."%"
			))));

			}
		
			
		
		}
					$tav=$this->_titlePercentSum/(count($titleSim)<1?1:(count($titleSim)));
					$dav=$this->_descPercentSum/(count($titleSim)<1?1:(count($titleSim)));
					$pt=($tav+$dav)/2;

			$average=array('titleAverage'=>$tav."%",
					'plagTest'=>$pt."%",
			'descAverage'=>$dav."%");
			// array_unique($titleSim);
			// $fieldNames = implode('`, `', array_values($titleSim));
			// print_r($titlSeSimVal);


			// die();
			array_push($titleSim,$average);
			// print_r($titleSim);
		FineMessages::word($this->_successMsg=array(TRUE,$titleSim,'Test Result'));

		die();

	}
	public function xhrSelectById()
	{
		// $serchBy=$_REQUEST['key'];
		$serchValue=strtolower($_REQUEST['id']);
	
		// print_r($serchValue);
		$res=$this->db->selectById($serchValue);
		if(!empty($res)){
			FineMessages::word($this->_successMsg=array(TRUE,$res,'Search Result'));
		}else{
			FineMessages::word($this->_successMsg=array(false,'No Search Result'));
        }
		
	}
	
	public function xhrDeleteListing()
	{
		$id = (int) $_POST['id'];
		$res=	$this->db->delete('projects', "id = '$id'");
		// print_r($res);
		// die();
		if($res){
			FineMessages::word($this->_successMsg=array(true,'Deleted Successfully'));
	    }
	}
	public function xhrLogOut()
	{
		Session::destroy();
		FineMessages::word($this->_successMsg=array(true,'Logged Out Successfully'));
	    
	}
	

}