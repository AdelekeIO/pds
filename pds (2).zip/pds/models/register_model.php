<?php

class Register_Model extends Model
{   
    private $_table='register';
    private $_login_tbl='login';
    public $_res1=null;
//    private $_successMsg=null;
    public function __construct()
	{
		parent::__construct();
	}

	public function run()
	{   
//            echo $_POST['fullName'];
            $data=array(
           
            'fullName'=>$_POST['fullName'],
            'username'=> $_POST['username'],
            'email'=> $_POST['email'],
            'password'=>Hash::create('sha256', $_POST['password'], HASH_PASSWORD_KEY),
            'comfirmPassword'=>Hash::create('sha256', $_POST['cpassword'], HASH_PASSWORD_KEY)
        
            );
        //    print_r($this->_res1);
    
            $res=$this->db->insert($this->_table,$data);
            
            if(!empty($res) && ($res!==FALSE)){
                
                $this->_res1=$this->db->insert($this->_login_tbl,array(
                    'email'=>$data['email'],
                    'uuid'=>Hash::create('sha256', $res, HASH_PASSWORD_KEY),
                    'password'=>Hash::create('sha256', $_POST['password'], HASH_PASSWORD_KEY),
                    'username'=> $_POST['username'],
                    'datetime'=> date('Y-m-d H:i:s', time()) ,
                    'status'=>0
                    ));
                    // id	uuid	password	username	datetime	status
            }
           
             FineMessages::word($this->_successMsg=array(TRUE,$this->_res1,'Registration Successful'));
            die();

	}
}