<?php
/**
 * 
 */
class Auth
{
	
	public static function handleLogin()
	{
		@session_start();
		$logged = $_SESSION['loggedIn'];
		echo $logged;
		if ($logged == false) {
			session_destroy();
			header('location: http://localhost:808/pds');
			exit;
		}
		// if($logged == true){
				
		// 		header('location: http://localhost:808/pds/dashboard');
		// 		exit;
			
		// }
		// elseif($logged==true){
		// 	header('location:  http://localhost:808/pds/dashboard');
		// 	exit;
		// }
	}
	
}