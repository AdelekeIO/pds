<?php

class Dashboard extends Controller {

	function __construct() {
		parent::__construct();
		// Auth::handleLogin();
		Dashboard::handleLogin2();
		$this->view->js = array('dashboard/js/default.js');
	}
	
	function settings() 
    {    
		Dashboard::handleLogin2();
		$this->view->title = 'Dashboard';
        $this->view->render('header');
        $this->view->render('dashboard/settings');
//        $this->view->render('footer');

       
    }
	function add() 
    {    
		Dashboard::handleLogin2();
        $this->view->title = 'Dashboard';
        $this->view->render('header');
        $this->view->render('dashboard/add');
//        $this->view->render('footer');
    }
	function view() 
    {  
		Dashboard::handleLogin2();  
        $this->view->title = 'Dashboard';
        $this->view->render('header');
        $this->view->render('dashboard/view');
//        $this->view->render('footer');
    }
	function sview() 
    {    Dashboard::handleLogin2();
        $this->view->title = 'Dashboard';
        $this->view->render('header');
        $this->view->render('dashboard/sview');
//        $this->view->render('footer');
    }
	function logout()
	{
		Session::destroy();
		header('location: ../../../../pds');
		die();
		exit;
	}
	function xhrAddProject(){
		$this->model->xhrAddProject();
		die();
	}
	function xhrPlagTest(){
		$this->model->xhrPlagTest();
		die();
	}
	
	function xhrInsert()
	{
		$this->model->xhrInsert();
	}
	
	function xhrSearch()
	{
		$this->model->xhrSearch();
	}
	
	function xhrGetListings()
	{
		$this->model->xhrGetListings();
	}
	
	function xhrSelectById()
	{
		$this->model->xhrSelectById();
	}
	
	function xhrDeleteListing()
	{
		$this->model->xhrDeleteListing();
	}
	function xhrLogOut()
	{
		$this->model->xhrLogOut();
		// Session::destroy();
		// header('location: ../../../../pds');
		// die();
	}
	
	public static function handleLogin2(){
		Session::init(); 
		if (!Session::get('loggedIn')){
			Session::destroy();
		   header('location: ../../../../pds');
		   die();
		 }
	}

}