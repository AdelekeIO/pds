<?php

class Register extends Controller {

	function __construct() {
		parent::__construct();
	}
	
	function index() {
		//echo Hash::create('sha256', 'jesse', HASH_PASSWORD_KEY);
		//echo Hash::create('sha256', 'test2', HASH_PASSWORD_KEY);
                $this->view->title = 'Register';
                $this->view->render('header');
		$this->view->render('register/index');
                $this->view->render('footer');
		
	}
	
//	function details() {
//		$this->view->render('index/index');
//	}
	function run()
	{
		$this->model->run();
	}
	
}